![image](https://i.imgur.com/YOUR_IMAGE_ID.png)

# Steve Annuario Astral

## Cos'è?
Un sistema completo per creare libri interattivi nel tuo server FiveM. Perfetto per guide RP, manuali, fumetti o qualsiasi contenuto visivo che vuoi condividere con i giocatori.

## Caratteristiche
- Libri interattivi con pagine sfogliabili
- Supporto per immagini locali, web e Discord
- Animazioni realistiche durante la lettura
- Performance ottimizzata (0.0ms)
- Configurazione semplice e flessibile

## Come funziona
1. Configura i tuoi libri nel file config.lua
2. Aggiungi gli oggetti al tuo inventario
3. I giocatori possono usare gli oggetti per leggere i libri
4. Sfoglia le pagine con il mouse

## Requisiti
- ox_lib
- QBCore Framework

## Supporto
Sito Web: https://astral-rp.it/
Discord Server: https://discord.gg/astralroleplay
